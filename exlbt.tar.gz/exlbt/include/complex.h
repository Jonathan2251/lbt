#ifndef _COMPLEX_H_
#define	_COMPLEX_H_

#define _Complex_I 1.0fi

#endif
