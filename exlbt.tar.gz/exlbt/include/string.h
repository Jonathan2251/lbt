#ifndef _STRING_H_
#define	_STRING_H_


#endif
