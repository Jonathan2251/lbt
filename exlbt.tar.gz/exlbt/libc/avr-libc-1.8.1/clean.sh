#!/usr/bin/env bash

rm -rf libc/stdio/obj
rm -rf libc/stdlib/obj
rm -rf libc/string/obj

