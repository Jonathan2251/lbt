#!/usr/bin/env bash

rm -rf obj

