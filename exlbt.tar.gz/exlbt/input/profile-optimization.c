int foo(int x) {
  if (x > 5)
    return x * 2;
  else
    return x + 1;
}

int main() {
  for (int i = 0; i < 10; ++i)
    foo(i);
  return 0;
}
