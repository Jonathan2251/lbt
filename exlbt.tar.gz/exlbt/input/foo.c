// foo.c
#include <stdio.h>

int foo(int x) {
    if (x > 10)
        return x * 2;
    else
        return x + 1;
}

int main() {
    for (int i = 0; i < 100; ++i)
        foo(i); // lots of calls where x > 10 is true more often
    return 0;
}
