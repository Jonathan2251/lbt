// RUN: %clang_builtins %s %librt -fnested-functions -o %t && %run %t
// REQUIRES: librt_has_trampoline_setup

#include <stdio.h>
#include <string.h>
#include <stdint.h>

/*
 * Tests nested functions
 * The ppc compiler generates a call to __trampoline_setup
 * The i386 and x86_64 compilers generate a call to ___enable_execute_stack
 */

/*
 * Note that, nested functions are not ISO C and are not supported in Clang.
 */

#if !defined(__clang__)

static typedef int (*nested_func_t)(int x);

static nested_func_t proc;

int trampoline_setup_test() {
    /* Some locals */
    int c = 10;
    int d = 7;
    
    /* Define a nested function: */
    int bar(int x) { return x*5 + c*d; };

    /* Assign global to point to nested function
     * (really points to trampoline). */
    proc = bar;
    
    /* Invoke nested function: */
    c = 4;
    if ( (*proc)(3) != 43 )
        return 1;
    d = 5;
    if ( (*proc)(4) != 40 )
        return 1;

    /* Success. */
    return 0;
}

#else

int trampoline_setup_test() {
    //printf("skipped\n");
    //return 0;
    return -1;
}

#endif
