#include "ch12_inherit.cpp"

int main() {
  int a = test_cpp_polymorphism();
  return 0;
}

