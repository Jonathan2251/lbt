build-cpu032II-el/printf-stdarg.c.o: printf-stdarg.c
