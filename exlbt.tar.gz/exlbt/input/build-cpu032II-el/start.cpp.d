build-cpu032II-el/start.cpp.o: start.cpp \
  /Users/chungshu/git/lbd/lbdex/input/start.h \
  /Users/chungshu/git/lbd/lbdex/input/config.h

/Users/chungshu/git/lbd/lbdex/input/start.h:

/Users/chungshu/git/lbd/lbdex/input/config.h:
