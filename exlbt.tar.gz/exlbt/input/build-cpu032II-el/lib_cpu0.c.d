build-cpu032II-el/lib_cpu0.c.o: lib_cpu0.c
