build-cpu032II-eb/printf-stdarg.c.o: printf-stdarg.c
