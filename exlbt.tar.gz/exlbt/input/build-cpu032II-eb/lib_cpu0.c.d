build-cpu032II-eb/lib_cpu0.c.o: lib_cpu0.c
