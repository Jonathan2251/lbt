build-cpu032II-eb/printf-stdarg-def.c.o: printf-stdarg-def.c \
  /Users/chungshu/git/lbd/lbdex/input/print.h \
  /Users/chungshu/git/lbd/lbdex/input/start.h \
  /Users/chungshu/git/lbd/lbdex/input/config.h

/Users/chungshu/git/lbd/lbdex/input/print.h:

/Users/chungshu/git/lbd/lbdex/input/start.h:

/Users/chungshu/git/lbd/lbdex/input/config.h:
