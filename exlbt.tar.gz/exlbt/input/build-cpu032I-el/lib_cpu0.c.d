build-cpu032I-el/lib_cpu0.c.o: lib_cpu0.c
