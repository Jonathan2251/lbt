build-cpu032I-el/debug.cpp.o: debug.cpp \
  /Users/chungshu/git/lbd/lbdex/input/debug.h

/Users/chungshu/git/lbd/lbdex/input/debug.h:
