build-cpu032I-el/printf-stdarg.c.o: printf-stdarg.c
