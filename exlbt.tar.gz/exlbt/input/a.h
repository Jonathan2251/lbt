extern int foo1(void);
extern void foo2(void);
extern int foo4(void);

