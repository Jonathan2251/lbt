rm -f *.o *.bc *.s a.out global_offset
