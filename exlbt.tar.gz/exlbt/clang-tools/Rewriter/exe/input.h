namespace A {
extern double abs(double d);
}
