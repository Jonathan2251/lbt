Build:
  clang++ dev-runtime.cpp kernel-map.cpp ../graph.cpp
Run:
  ./a.out
