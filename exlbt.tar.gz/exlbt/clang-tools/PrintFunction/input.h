#ifndef INPUT_H
#define INPUT_H

struct Type0 {
};

struct Type1 {
};

extern void GetFuncAndArgs(Type0 *Arg0, Type1 &Arg1, Type0 Arg2[],
            int N);

#endif
