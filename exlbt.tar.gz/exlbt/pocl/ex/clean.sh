rm -f *.o *.d a.out
